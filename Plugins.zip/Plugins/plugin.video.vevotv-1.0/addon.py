import xbmc
import xbmcgui
import xbmcaddon

addon = xbmcaddon.Addon('plugin.video.vevotv')
title = addon.getAddonInfo('name')
icon = addon.getAddonInfo('icon')
link = 'http://vevoplaylist-live.hls.adaptive.level3.net/vevo/ch1/06/prog_index.m3u8'

li = xbmcgui.ListItem(label=title, iconImage=icon, thumbnailImage=icon, path=link)
li.setInfo(type='Video', infoLabels={ "title": title })
li.setProperty('IsPlayable', 'true')

xbmc.Player().play(item=link, listitem=li)